(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_71263d.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_71263d.js",
  "chunks": [
    "static/chunks/src_2a3aee._.js",
    "static/chunks/node_modules_recharts_es6_util_44d8fd._.js",
    "static/chunks/node_modules_recharts_es6_component_d5776c._.js",
    "static/chunks/node_modules_recharts_es6_cartesian_114dc9._.js",
    "static/chunks/node_modules_recharts_es6_chart_3ece68._.js",
    "static/chunks/node_modules_recharts_es6_polar_024f0f._.js",
    "static/chunks/node_modules_recharts_es6_4eb7ca._.js",
    "static/chunks/node_modules_lodash_7678ac._.js",
    "static/chunks/node_modules_e5ef2e._.js",
    "static/chunks/node_modules_react-apexcharts_dist_react-apexcharts_min_16abb8.js"
  ],
  "source": "dynamic"
});
